
namespace LogicTier
{
    public class Class1
    {
    }

}
